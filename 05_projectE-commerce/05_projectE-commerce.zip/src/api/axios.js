import axios from 'axios'

const api = axios.create({
  baseURL: 'https://server-for-react.httpskasra.workers.dev',
  headers: {
    'Content-Type': 'application/json',
  },
})

export default api
